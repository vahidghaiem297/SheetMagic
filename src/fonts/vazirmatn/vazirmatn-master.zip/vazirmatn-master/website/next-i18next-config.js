module.exports = {
  react: {
    useSuspense: false,
    wait: true,
  },
};
